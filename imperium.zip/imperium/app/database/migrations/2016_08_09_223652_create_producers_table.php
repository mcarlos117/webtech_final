<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProducersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('producers', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('KID');
			$table->integer('UID');
			$table->integer('smith');
			$table->integer('lumbermill');
			$table->integer('mine');
			$table->integer('farm');
			$table->integer('well');
			//$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('producers');
	}

}
