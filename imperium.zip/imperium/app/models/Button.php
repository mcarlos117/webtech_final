<?php

class Button extends Eloquent  {

	protected $table = 'buttons';

	protected $fillable = ['KID','count'];

}