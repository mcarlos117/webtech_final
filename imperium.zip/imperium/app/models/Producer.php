<?php

class Producer extends Eloquent  {

	protected $table = 'producers';

	protected $fillable = ['KID','UID','smith','lumbermill','mine','farm','well'];

}