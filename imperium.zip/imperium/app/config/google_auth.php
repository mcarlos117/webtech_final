<?php
	return array(
		"base_url" => "http://localhost:8000/gauth/auth",
		"providers" => array (
			"Google" => array (
				"enabled" => true,
				"keys" => array("id" => "210992275703-3vsf5vhtm1ov8omt6jodaphddqabth2d.apps.googleusercontent.com", "secret" => "zFXHoj1cGbJMnWjNr3BEgi6k")/*,
				"scope"  => "https://www.googleapis.com/auth/userinfo.profile". "https://www.googleapis.com/auth/userinfo.email"	*/
	)));