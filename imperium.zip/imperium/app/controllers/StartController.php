<?php

class StartController extends BaseController {

	public function goThere(){
		return View::make('start');
	}
}