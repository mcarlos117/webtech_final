<?php

class MarketController extends BaseController {

	public function showMarketView(){
		$username = Auth::user();
		//return View::make('market');

		$posts = Trade::where('posterID', '=', $username->id)->get();


		return View::make('market', [
			'username' => $username,
			'posts'	=> $posts
		
		]);
	}

	


	


}