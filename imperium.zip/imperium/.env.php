<?php

return [
	'DB_NAME' => 'imperium',
	'DB_USERNAME' => 'root',
	'DB_PASSWORD' => '',
	];