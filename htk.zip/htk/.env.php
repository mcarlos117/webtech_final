<?php

return [
	'DB_NAME' => 'htk',
	'DB_USERNAME' => 'root',
	'DB_PASSWORD' => '',
	];